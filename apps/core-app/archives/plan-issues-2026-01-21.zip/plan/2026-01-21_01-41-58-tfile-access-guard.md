---
mode: plan
cwd: /Users/talexdreamsoul/Workspace/Projects/talex-touch/apps/core-app
task: 梳理 tfile 协议限制与插件权限，新增敏感路径确认流程
complexity: complex
planning_method: builtin
created_at: 2026-01-21T01:42:05+08:00
---

# Plan: tfile 协议权限与敏感路径保护

🎯 任务概述
需要梳理 tfile 协议的访问路径与调用场景，阻止任意本地文件被加载。
在此基础上新增插件 tfile 权限与作用域限制（sdkapi 260121），并对非 app 内路径统一弹窗确认。

📋 执行计划
1. 现状梳理：盘点 tfile 入口（`file-protocol`、`system.readFile`）与渲染层使用点，明确哪些路径/场景属于核心功能必须保留。
2. 安全策略定义：明确“app 内”路径范围、插件 tfile 作用域规则（允许目录/文件模式），确认新权限命名与风险等级。
3. SDK/权限定义更新：新增 `SdkApi.V260121` 并更新 `CURRENT_SDK_VERSION`/支持列表；在权限注册表新增 tfile 权限与 i18n 文案。
4. 主进程 tfile 守卫：在 `FileProtocolModule` 与 `system.readFile` 统一做路径规范化与范围校验；区分核心窗口与插件窗口来源。
5. 敏感 tfile 弹窗流程：新增请求通道与 session 级允许列表；实现“拒绝 / 本次允许 / 关闭前始终允许”三种处理。
6. 插件权限接入：manifest 增加 tfile 权限声明与作用域字段；插件启用流程缺失权限时触发确认。
7. 测试与回归：补充权限模块与 tfile 守卫单元测试；手动验证文件预览、图标、主题背景等核心场景。
8. 文档与迁移说明：记录新 sdkapi 版本要求与插件权限变更说明，明确旧插件的兼容行为。

⚠️ 风险与注意事项
- “app 内”范围定义不清会导致核心功能受阻或权限形同虚设，需要产品/安全确认。
- tfile 请求来源识别（插件/主窗口）可能受 WebContents 关联限制，需验证 Electron 能否可靠定位。
- 弹窗频率过高会影响体验，需要合并/节流策略与合理的默认允许范围。

📎 参考
- `src/main/modules/file-protocol/index.ts`
- `src/main/channel/common.ts`
- `src/main/modules/permission/index.ts`
- `src/main/modules/permission/permission-guard.ts`
- `src/renderer/src/composables/usePermissionStartup.ts`
- `src/renderer/src/composables/usePluginPermission.ts`
- `src/renderer/src/components/permission/PermissionRequestDialog.vue`
- `packages/utils/permission/registry.ts`
- `packages/utils/plugin/sdk-version.ts`
