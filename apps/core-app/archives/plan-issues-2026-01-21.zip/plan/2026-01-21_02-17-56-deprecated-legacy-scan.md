---
mode: plan
cwd: /Users/talexdreamsoul/Workspace/Projects/talex-touch/apps/core-app
task: 全仓扫描兼容性/老旧/Deprecated/Legacy 代码并分类
complexity: medium
planning_method: builtin
created_at: 2026-01-21T02:18:00+08:00
---

# Plan: 兼容性/老旧代码全仓扫描与分类

🎯 任务概述
本任务需要在 core-app 仓库内系统扫描兼容性、老旧与 deprecated/legacy 相关实现，并按“仍被使用但不推荐”、“兼容性/过渡性代码”、以及“其他可疑老旧模式”分组输出。目标是提供一份可追踪、可回溯的清单，便于后续治理与清理。

📋 执行计划
1. 统一判定口径与关键词集合，明确分类标准（deprecated/legacy/compat/shim/fallback/polyfill/migration 等）并记录为本次扫描准则。
2. 使用 MCP 搜索工具进行全仓语义+结构化检索，覆盖注释、JSDoc/TS 注解、配置与脚本，形成初始命中文件列表。
3. 分模块深读命中结果（main/renderer/packages/plugins/docs），逐条判断是否“仍在用但不推荐”或“兼容性/过渡路径”，并补充上下文说明。
4. 扩展到“隐性兼容代码”模式：版本门控、平台分支、旧协议/旧数据结构支持、feature flag 退路等，补充未命中的路径。
5. 汇总成分类清单，输出每条的文件位置、触发条件、依赖/替代方案与风险等级。
6. 交叉复核与遗漏补扫：对关键模块（渠道/插件/存储/数据库/构建）做二次检索，确认覆盖率并记录未决项。

⚠️ 风险与注意事项
- 仅凭关键词检索可能遗漏“隐性兼容路径”，需要结合版本门控与平台分支逻辑进行人工补扫。
- 大仓扫描成本较高，需控制检索范围与批次，避免遗漏与重复判断。
- 部分历史兼容路径可能与用户数据或插件生态绑定，分类时需标注潜在影响。

📎 参考
- 扫描完成后补充具体 `文件:行号` 引用与证据链接。
